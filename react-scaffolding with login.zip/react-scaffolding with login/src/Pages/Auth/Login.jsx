import {useState} from 'react';
import userSelector from "../../App/Redux/User/Selectors/userSelector";
import {userLogin} from "../../App/Redux/User/Slices/userSlice";
import {useDispatch} from "react-redux";

const Login = () => {

    const [form , register] = useState({});
    const dispatch = useDispatch();
    const user = userSelector();

    const onSubmit = async (e) => {
        e.preventDefault();
        dispatch(userLogin(form));
        register({});
    }

    return(
      <form autoComplete="off" onSubmit={onSubmit}>
          <input type='email'
                 value={form.email ?? ''}
                 placeholder='email'
                 onChange={(e) => register(
                     {...form, email : e.target.value })
                 }
          />
          <input
                 type='password'
                 value={form.password ?? ''}
                 placeholder='password'
                 onChange={(e) => register(
                     {...form, password : e.target.value })
                 }
          />

          <h1>{}</h1>

          {user.isLoggingIn && <h1>Loading....</h1>}

          <button type='submit'>Login</button>
      </form>
    );
}

export default Login;