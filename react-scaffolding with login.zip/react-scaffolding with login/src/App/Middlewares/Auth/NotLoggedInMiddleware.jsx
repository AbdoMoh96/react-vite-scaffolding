import { Navigate } from "react-router-dom"


function ProtectedRedirect({children }) {
    const user = JSON.parse(localStorage.getItem('user'));

    if(user !== null){
        return <Navigate exact to="/home" />;
    }else{
        return children;
    }
}

export default ProtectedRedirect;