import axios from "axios";

const customerApi = axios.create({
    baseURL: 'https://example.com/api/',
    headers: {'X-Custom-Header': 'foobar'}
});

/*
const instance = axios.create({
    baseURL: 'https://some-domain.com/api/',
    timeout: 1000,
    headers: {'X-Custom-Header': 'foobar'}
});*/


export default customerApi;
