import { configureStore } from '@reduxjs/toolkit';
import reducers from "../Counter/reducers";

export const store = configureStore({
    reducer: {
        main : reducers
    },
    devTools : process.env.NODE_ENV === 'development'
});

export default store;