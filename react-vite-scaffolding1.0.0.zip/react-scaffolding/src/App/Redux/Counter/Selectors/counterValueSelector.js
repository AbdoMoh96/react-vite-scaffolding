import {useSelector} from "react-redux";

const counterValueSelector = () => {
    return useSelector((state) => state.main.counter.value);
}

export default counterValueSelector;